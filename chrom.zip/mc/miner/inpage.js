if(miner.isRunning()){

}