thissiteconfig={
    'domain':'douyu',
    'praisenummax':3
}
var withpause=false
var thissitemouseport='localhost:9000';
chrome.runtime.sendMessage({'msgtype':'getdebugmode'},function(response){
    var msg = response
    localStorage.debugging = msg.debugging;
});

localStorage.praisenummax=2
//localStorage.forwardnummax=2
localStorage.commentnummax=2
var randtimebase=2000;//8seconds
var randtime=Math.floor(Math.random()*randtimebase);
console.log("randtime:"+randtime)

var t2s=2000+randtime;
var t3s=3000+randtime;
var t4s=4000+randtime;
var t5s=5000+randtime;
var t6s=6000+randtime;
var t7s=7000+randtime;
var t8s=8000+randtime;
var t9s=9000+randtime;
var t10s=10000+randtime;
var t15s=15000+randtime;
var t20s=20000+randtime;
var t25s=25000+randtime;
var t30s=30000+randtime;
var t35s=35000+randtime;
var t40s=40000+randtime;

function searchnext() {
    chrome.runtime.sendMessage({'msgtype':'getnextmission'},function (msg) {
        jQuery('#suggest-search').val(msg.mastername);
        jQuery('a[class="s-ico fr"]').click();

    })
}



function commonlogin(leavfunc){
    chrome.runtime.sendMessage({'msgtype':'getuserandproxy'},function(response){

        jQuery('a[class="u-reg fl"]')[0].click();
        ajaxcheck(function () {
            var loginframe=jQuery('#login-passport-frame').contents();
            return loginframe.find('div[class="qrcode-img"]').find('canvas').length>0;
        },function () {
            var loginframe=jQuery('#login-passport-frame').contents();
            loginframe.find('div[class="scanicon-toLogin js-qrcode-switch"]').click()
            //loginframe.find('span[class="l-stype js-l-stype"]').click()
            loginframe.find('span:contains("手机登录")').click();
            loginframe.find('input[name="phoneNum"]').val(response.account);
            loginframe.find('input[name="password"]').val(response.password);
            douyulogin(leavefunc);
        },function () {
            cantcontinue()
        },t7s,6)

    });
}

//can't use
function checknick(){
    var tmpnick=user.account;
    jQuery.ajax({
        url:'https://passport.douyu.com/api/nicknameCheck',
        type:'post',
        data:{nickname:tmpnick,clt:0},
        datatype:'json',
        xhrFields: {
            withCredentials: true
        },
        crossDomain:true,
        success:function(data){
            console.log(data);
            if(data.error==0){
                if (nickaddind>0){
                    console.log('new nick:'+tmpnick)
                    reportchangeuser()
                }

            }else {
                nickaddind++
                tmpnick=user.account+nickaddind;
                checknick()
            }
        }
    })
}
function reportchangeuser() {
    user['msgtype']='changeuser';
    chrome.runtime.sendMessage(user)
}

function commonregister(leavfunc){
    chrome.runtime.sendMessage({'msgtype':'getuserandproxy'},function(response){
        user=response
        //jQuery('a[class="u-reg fl"]')[0].click();
        runinpage(clickreg)
        ajaxcheck(function () {
            var loginframe=jQuery('#login-passport-frame').contents();
            //if(loginframe.find('.scancode-title').filter(':visible').length>0){
            if(loginframe.find('span:contains("点击按钮进行验证")').length==0){
                document.getElementById('login-passport-frame').contentWindow.location.reload(true);
                return 0
            }else{
                return 1
            }

        },function () {
            passCAPTCHA(douyuregister1,function () {
                chrome.runtime.sendMessage({'msgtype':'removecache'},function (response) {
                    console.log(response)
                    if(!response){
                        console.log('removecache error')
                    }else {
                        console.log('remove cache success,reload')
                        window.location.reload()
                    }
                })
            },1);
        },function () {
            cantcontinue()
        },t5s,6)
    });
}

function clickreg() {
    jQuery('a[class="u-reg fl"]')[0].click();
}

function douyuregister1() {
    chrome.runtime.sendMessage({'msgtype':'getphone'},function(response){
        console.log(response)
        var loginframe=jQuery('#login-passport-frame').contents();
        loginframe.find('input[name="phoneNum"]').val(response.phone);
        loginframe.find('input[name="password"]').val(user.password);
        loginframe.find('input[type="button"]').click();


        setTimeout(checkmsgsend1,10*1000)
    })
}

function checkmsgsend1() {
    var loginframe=jQuery('#login-passport-frame').contents();
    var sendbutton=loginframe.find('input[type="button"]')
    if (sendbutton.hasClass('long')){
        chrome.runtime.sendMessage({'msgtype':'getmsg'},function(response){
            var loginframe=jQuery('#login-passport-frame').contents();
            loginframe.find('input[name="phoneCaptcha"]').val(response.msg)
            loginframe.find('input[type="submit"]').click()
            setTimeout(setnick,5*1000)
        })
    }else {
        passCAPTCHA(douyuregister1,logout,1)
    }

}

function setnick() {
    var loginframe=jQuery('#login-passport-frame').contents();
    loginframe.find('input[name="reName"]').val(user.nickname);
    setTimeout(function () {
        loginframe.find('button[class="reg-succ-btn js-submit"]').click();
    },4000)
    setTimeout(nickguess1,12*1000)
}

function nickguess1() {
    var loginframe=jQuery('#login-passport-frame').contents();
    if(loginframe.find('button[class="reg-succ-btn js-submit"]').length>0) {
        if(nickaddind==0){
            nickaddind=1;
            tmpnick=user.nickname+randomString(3);
            user.nickname=tmpnick;
            reportchangeuser()
            setnick()
        }else {
            logout('regfail,nickerror')
        }
    }else{
        console.log('error,not considered')
    }
}

function douyuregister() {
    var loginframe=jQuery('#login-passport-frame').contents();
    loginframe.find('input[name="nickname"]').val(user.nickname)
    loginframe.find('input[name="password"]').val(user.password)
    loginframe.find('input[name="password2"]').val(user.password)
    loginframe.find('input[value*="注册"]')[0].click();
    setTimeout(nickguess,10*1000)
}

var nickaddind=0
function nickguess() {
    var loginframe=jQuery('#login-passport-frame').contents();
    if(loginframe.find('a:contains("注册斗鱼")').filter(':visible').length>0) {
        if(nickaddind==0){
            nickaddind=Math.floor(Math.random()*20+1)
            tmpnick=user.nickname+nickaddind;
            user.nickname=tmpnick;
            passCAPTCHA(douyuregister,logout,1);
        }else {
            logout('regfail,nickerror')
        }

    }else{
        if (nickaddind>0){
            console.log('new nick:'+tmpnick)
            reportchangeuser()

        }
        passCAPTCHA(douyuregisterbindphone,logout,1)
    }
}

function douyuregisterbindphone() {
    chrome.runtime.sendMessage({'msgtype':'getphone'},function(response){
        console.log(response)
        var loginframe=jQuery('#login-passport-frame').contents();
        loginframe.find('input[name="bindphonenum"]').val(response.phone)
        loginframe.find('input[type="button"]').click()
        setTimeout(checkmsgsend,20*1000)
    })
}

function checkmsgsend() {
    var loginframe=jQuery('#login-passport-frame').contents();
    var sendbutton=loginframe.find('input[type="button"]')
    if (sendbutton.hasClass('long')){
        chrome.runtime.sendMessage({'msgtype':'getmsg'},function(response){
            var loginframe=jQuery('#login-passport-frame').contents();
            loginframe.find('input[name="phoneCaptcha"]').val(response.msg)
            loginframe.find('button').click()
            setTimeout(checksuccess,5*1000)
        })
    }else {
        passCAPTCHA(douyuregisterbindphone,logout,1)
    }

}

function checksuccess(){
    var loginframe=jQuery('#login-passport-frame').contents();

    if(loginframe.find('.apply-anchor').filter(':visible').length>0){
        window.location.reload()
    }else {
        setTimeout(checksuccess,5*1000);
    }
}




function douyuregisterscreen(leavefuncN0) {
    loginleavefunc=leavefuncN0?leavefuncN0:function () {
        console.log('default registerleavefunc')
    }
    successfunc()
    var successfunc=function () {
        jQuery.ajax( {
            url:'http://'+thissitemouseport+'/screen',// 跳转到 action
            data:{'msgtype':'douyuregister'},
            type:'get',
            cache:false,
            dataType:'json',
            timeout:mousetimeout,
            success:function(data) {

                if(data.uimsgtype[0]=='s'){
                    var loginframe=jQuery('#login-passport-frame').contents();
                    loginframe.find('input[value*="注册"]')[0].click();

                }else {
                    logout();
                }
            },
            error : function(jqxhr,text) {

                jqxhr.abort()
                // view("异常！");
                setTimeout(function () {
                    douyulogin();
                },2*1000)

                console.log("changewindowstate 异常！");
            },
            complete: function (XHR, TS) {
                XHR = null;
                loginleavefunc()
            }
        });
    }
}


function douyulogin(leavefuncN0=Object) {

    successfunc()
    var successfunc=function () {
        jQuery.ajax( {
            url:'http://'+thissitemouseport+'/screen',// 跳转到 action
            data:{'msgtype':'douyulogin'},
            type:'get',
            cache:false,
            dataType:'json',
            timeout:mousetimeout,
            success:function(data) {

                if(data.uimsgtype[0]=='s'){
                    var loginframe=jQuery('#login-passport-frame').contents();
                    loginframe.find('input[value="登录"]')[0].click();

                }else {
                    logout();
                }
            },
            error : function(jqxhr,text) {

                jqxhr.abort()
                // view("异常！");
                setTimeout(function () {
                    douyulogin();
                },2*1000)

                console.log("changewindowstate 异常！");
            },
            complete: function (XHR, TS) {
                XHR = null;
                loginleavefunc()
            }
        });
    }
}

jQuery('.scancode-title').filter(':visible').length
function logout(){
    chrome.runtime.sendMessage({'msgtype': 'reportlogout'});
}
var adschecktimes=8
function closeads() {
    adschecktimes--;

    var adsarray=['.double-festival-close','.guess-guide-close','div[class="close"]',
        'div[class="pay-give-close"]']

    for (ad in adsarray){
        if(jQuery(adsarray[ad]).length>0){
            jQuery(adsarray[ad]).each(function(i){jQuery(this).click()});
        }
    }


    if(adschecktimes>0){
        setTimeout(closeads,5000);
    }
}


function ismasteronline() {
    return jQuery('#anchor-info').text().indexOf('上次直播').length>=0;
}
function passCAPTCHAc(successfunc=Object, failfunc=Object,keep) {
    var a = new Error().stack.match(/at (.*?) /);
    var thisname=a[1]
    console.log('funccall:'+thisname);
    chrome.runtime.sendMessage({'msgtype': 'passCAPTCHA','keep':keep},function (response) {
        console.log(response)
        if(response.uimsgtype[0]=='s'){
            successfunc()

        }else {
            failfunc()
        }
    });
}
function passCAPTCHA(successfunc=Object, failfunc=Object,keep) {
    var a = new Error().stack.match(/at (.*?) /);
    var thisname=a[1]
    console.log('funccall:'+thisname);
    jQuery.ajax( {
        url:'http://'+thissitemouseport+'/screen',// 跳转到 action
        data:{'msgtype':'passCAPTCHA'},
        type:'get',
        cache:false,
        dataType:'json',
        timeout:mousetimeout,
        success:function(data) {
            console.log(data);
            if(data.uimsgtype[0]=='s'){
                successfunc()
            }else {
                failfunc()
            }
        },
        error : function(jqxhr,text) {

            jqxhr.abort()
            // view("异常！");
            if(keep){
                setTimeout(function () {
                    passCAPTCHA(successfunc, failfunc,keep);
                },5*1000)
            }


            console.log("passCAPTCHA 异常！");
        },
        complete: function (XHR, TS) {
            XHR = null;
        }
    });
}
function pausedouyuc(successfuncd=Object,failfuncd=Object,keep=0) {
    chrome.runtime.sendMessage({'msgtype': 'pausedouyu','keep':keep},function (response) {
        console.log(response)
        if (response.uimsgtype == 'pause') {
            successfuncd()
        }  else {
            failfuncd()
        }
    });
}
function pausedouyu(successfuncd=Object,failfuncd=Object,keep=0) {
    var thisname=getFuncName(this)
    if (!withpause){
        setTimeout(successfuncd,10*1000)
        
    }else{
        jQuery.ajax( {
            url:'http://'+thissitemouseport+'/screen',// 跳转到 action
            data:{'msgtype': 'pausedouyu'},
            type:'get',
            cache:false,
            dataType:'json',
            timeout:mousetimeout,
            success:function(data) {
                if (data.uimsgtype == 'pause') {
                    successfuncd()
                }  else {
                    failfuncd()
                }
            },
            error : function(jqxhr,text) {

                jqxhr.abort()
                // view("异常！");
                if(keep){
                    setTimeout(function () {
                        pausedouyu(successfuncd,failfuncd,keep);
                    },2*1000)
                }


                console.log(thisname+" 异常！");
            },
            complete: function (XHR, TS) {
                XHR = null;
            }
        });
    }

}

function getpagedescribe() {
    if(jQuery('.PlayerCase').length>0){
        return 'masterhome'
    }else if(window.location.href=="https://www.douyu.com/"){
        return "douyuhome"
    }else{
        return 'other'
    }
}

function isonline(){
    if(jQuery('.time-v-con').length>0){
        return 1;
    }else{
        return 0;
    }
}

closeads()