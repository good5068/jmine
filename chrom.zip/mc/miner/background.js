﻿//////////////////////config//////////////////////
seperatorusercomment='(u+--c)'
seperatoruseruser='(u-+u)'
var userstatetimeout=45*1000 //login time out
var userstatetimeoutSecond=60*1000
var testmode = 0;
var setproxy=1
if(testmode){
	setproxy=0;
}
var thisdomain='bocai';

var checkuserstatetimeout = 20*1000;
var thisport=':10032'
var localagent='localhost'+':8081'
var thissitemouseport='localhost:9000';
var thissiterobotport = serveraddress+thisport;
var QUERYUSERCYCLE=10*1000
var QUERYPROXYUSERCYCLE=30*1000
//////////////////////config//////////////////////
var userstatetimeoutAfterlogin = 120*1000
var logined=false
strictmode=true;
strictmodeoptimize=true;
withcookie=true;
withmissionmode=true;
singleusertotaltimeMax=12*60*1000;
steps=6



missionmodedict={'jump':0.4,'background':0.6}
var domainobj={'domain':'bocai','firsturl':'http://tzcl.tyccvip.com/','cookiedomain':'.tyccvip.com','pac':
	"if(shExpMatch(host, '*..tyccvip.com/')){return 'PROXY MYOWENIPPORT';}"
};
var homeurl='http://tzcl.tyccvip.com/';
var hostarray=["http://tzcl.tyccvip.com/"];
var jumparray=["http://www.sohu.com/","http://www.qq.com/"];
chrome.runtime.onMessage.addListener(messegelistener);

///////////////////////////////
totalvisitmode=true


directmode=true
disableuserstate=true
totalvisitmin=1*60*1000
totalvisitmax=4*60*1000

if(directmode){
    localagent=thissiterobotport
    mode='proxy';
}


//////////////////////////////
//alert('start');
var userarray=new Array();
//从userarray中查找user



var pacstart="var FindProxyForURL = function(url, host){";
var pacend=		"return 'DIRECT'"+
	"}";

blogmasterobj={}
///////////////////////////////
var walsuccessrate=0.3;



//start()


focuslist=new Array()
function inituserstate(){
	userhometabid=null;
	listtabid=null;
	focuslist=[];
	jumped=false;
}
function thissitemessagelistener(msg, sender, sendResponse) {
	if(msg['msgtype']=='reporttabid'){
		if(msg['tabname']=='userhome'){
			userhometabid=sender.tab.id;
		}else if(msg['tabname']=='list'){
			listtabid=sender.tab.id;
		}
	}
}

function thissitevisitnext(visitlast) {
	var visitlast = arguments[0] ? arguments[0] : 0;
	if(missionmode=='search'){
		if(userhometabid==null){
			chrome.tabs.create({url:homeurl},function (tab) {
				userhometabid=tab.id;
			})
		}
	}else if(missionmode=='background'){
		visitlast?usertovisitindex:usertovisitindex++;
		if(usertovisitindex>=usertovisit.length){
			backgroundLogout(null);
			return;
		}
		setTimeout(function () {
			var url = blogmasterobj[usertovisit[usertovisitindex]]
			chrome.tabs.create({url:url});
		},5000)
	}else if(missionmode=='jump'){
		var ind=Math.floor(Math.random()*jumparray.length)
		openurl(jumparray[ind]);

	}else{
		myConsoleLog(2,'mode error')
	}
}





///////////////////////////////////////////////////unused functions