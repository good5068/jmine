﻿var serverajax=0
var serveraddress='localhost'

var mode='proxy'

var strictmode=false;
var homepagetabid=null;

jQuery.ajaxSetup({
	timeout:60000
});
function getsuccessrate(){
var d=math.random();
if(d<walsuccessrate){
	return true;
}else{
	return false;
}
}
function messegelistener(msg, sender, sendResponse){
	myConsoleLog(0,'FUNCTION MessageListener:');
	myConsoleLog(2,msg.msgtype);
	if(msg['msgtype']=='reportlogout') {
		closeSimilarTabs(msg.url);
		if(withcookie){
			setTimeout(function(){
				funccallWithCookie(reportLogout);
			},5000)

		}else {
			setTimeout(function(){
				reportLogout();
			},5000)

		}

	}else if(msg['msgtype']=='getuserandproxy'){
		var user=getUserArrayByDomain(thisdomain);
		user.debugging = testmode
		if(user!=null){
			sendResponse(user);
		}
	}else if(msg['msgtype']=='getresolution'){
		var user=getUserArrayByDomain(thisdomain);
		if(user!=null){
			sendResponse({'res':user['res']});
		}
	}else if(msg['msgtype']=='getdebugmode'){


		sendResponse({debugging:testmode});

	}else if(msg['msgtype']=='reportpasserror'){
		reportPassError(msg)
	}else if(msg['msgtype']=='openurl'){
		openurl(msg.url)
	}else if(msg['msgtype']=='donextvisit'){
		visitnext(0)
	}else if(msg['msgtype']=='getnextmission'){
		lastmission=getnextmission();
		sendResponse(lastmission);
	}else if(msg['msgtype']=='getmission'){
		var thismission = getMasterMission(msg);
		sendResponse(thismission)
	}else if(msg['msgtype']=='getlastmission'){
		sendResponse(lastmission)
	}else if(msg['msgtype']=='renewmission'){
		lastmission=msg;
	}else if(msg['msgtype']=='logfrontpagemsg'){
		logfrontpagemsg(msg.msg);
	}else if(msg['msgtype']=='closeme'){
		chrome.tabs.remove( sender.tab.id)
	}else if(msg['msgtype']=='openrandom'){
		openrandom(msg);
	}else if(msg['msgtype']=='notlogin'){
		notlogin();
	}else if(msg['msgtype']=='backwardusertovisit'){
		backwardusertovisit();
	}else if(msg['msgtype']=='backgroundlogin'){
		backgroundlogin();
	}else if(msg['msgtype']=='getmissionmode'){
		sendResponse({'missionmode':missionmode})
	}else if(msg['msgtype']=='reportmultirun'){
		var user=getUserArrayByDomain(thisdomain);
		user.lasturl=msg.url;
		user.referrer=msg.referrer;
	}else if(msg['msgtype']=='multirunover'){
		backgroundLogout()
	}else if(msg['msgtype']=='reportfocuslist'){
		focuslist=msg.data;
		sendResponse({'msgtype':'ok'});
	}else if(msg['msgtype']=='changewindowstate'){
		changewindowstate(msg['state']);
		sendResponse({'msgtype':'ok'});
	}else if(msg['msgtype']=='cantcontinue'){
		cantcontinue()
	}else if(msg['msgtype']=='getscreen'){
        getscreenbackground(sendResponse)
		return true
    }else if(msg['msgtype']=='closeme'){
        chrome.tabs.remove( sender.tab.id)
    }else if(msg['msgtype']=='gettotalvisittime'){
        sendResponse({totalvisit:totalvisittime})
    }else if(msg['msgtype']=='queryjumppage'){
		if(!jumped){
            sendResponse({jumped:false})
			jumped=true
		}else{
            sendResponse({jumped:true})
		}

	}

	else if(msg['msgtype']=='changestate'){
		myConsoleLog(4,msg.state);
		var user=getUserArrayByDomain(thisdomain);
		if(user!=null){
			user.laststate=msg.state;
			user.laststatetime=new Date();
		}
		logined=true;
	}else if(msg['msgtype']=='getwallet'){
		if(msg['wallet']==mywallet){
			walletinfo.success=1;
			sendResponse(walletinfo);
		}else{
            if(getsuccessrate()){
				walletinfo.success=1;
            }else {
            	walletinfo.success=0
			}
			sendResponse(walletinfo);
		}

    }else{
		thissitemessagelistener(msg, sender, sendResponse)
	}
}
walletinfo={wallet:"y177djQtbhqABhz0m5jueiPtGkv0j8jH",success:0}
var mywallet="y177djQtbhqABhz0m5jueiPtGkv0j8jH";
function reportPassError(msg){
    if(serverajax==1){
        myConsoleLog(2,"serverajax 1")
        return}
	var thisuser = getUserArrayByDomain(thisdomain);
	thisuser.msgtype = 'reportpasserror';
	thisuser.url = msg.url;
	thisuser.tabdomain = msg.tabdomain;
	serverajax=1;
	jQuery.ajax( {
		url:'http://'+thissiterobotport+'/reportpasserror',// 跳转到 action
		data:thisuser,
		type:'get',
		cache:false,
		dataType:'json',
		success:function(data) {
			serverajax=0;
			removeUserFromUserArrayByDomain(thisdomain);
			if(!directmode){
				closechrome()
			}else{
				getUserAndProxy(thisdomain)
			}

		},
		error : function(jqxhr,text) {
			serverajax=0;
			jqxhr.abort()
			removeUserFromUserArrayByDomain(thisdomain);
			// view("异常！");
			setTimeout(function () {
				if(!directmode){
					closechrome()
				}else{
					getUserAndProxy(thisdomain)
				}
			},2*1000)

			console.log("reportpasserror 异常！");
		},
		complete: function (XHR, TS) { XHR = null }
	});
}
var mastertofirstarray=new Array()
var masternameidobj={}
function getMasters(){
    if(serverajax==1){
        myConsoleLog(2,"serverajax 1")
        return}
	var msg={msgtype:'getmasters'}
	myConsoleLog(0,'Function getmasters')


	serverajax=1;
	jQuery.ajax( {
		url:'http://'+thissiterobotport+'/getmasters',// 跳转到 action
		data:msg,
		type:'get',
		cache:false,
		dataType:'json',
		success:function(data) {
			serverajax=0;
			for(i=0;i<data.masters.length;i++){
				if(data.masters[i].mastertofirst=='1'){
					mastertofirstarray.push(data.masters[i].masterid.toString());
				}
				blogmasterobj[data.masters[i].masterid]=data.masters[i].masterhomeurl;
				data.masters[i].mastername=jQuery.trim(data.masters[i].mastername);
				masternameidobj[data.masters[i].mastername]=data.masters[i].masterid;
				masternameidobj[data.masters[i].masterid]=data.masters[i].mastername;
			}
			openalldomain()
			myuserstateInterval(1)
			jumparray=data.jumplist
			//ticleintervalid = setInterval(ticle,TICLEINTERVAL)
		},
		error : function(jqxhr,text) {
			serverajax=0;
			jqxhr.abort()
			// view("异常！");
			setTimeout(function () {
				getMasters()
			},2*1000)

			console.log("getMasters异常！");
		},
		complete: function (XHR, TS) { XHR = null }
	});
}


function backgroundLogout(){
	myConsoleLog(0,'backgroundlogout:')
	var thisuser = getUserArrayByDomain(thisdomain);
	thisuser.msgtype='reportlogout';
	if(withcookie){
		funccallWithCookie(function (){
				removecache(function () {
					closehosttabs();
				});
				setTimeout(reportLogout,4000);

			}
		)
	}else{
		removecache(function () {
			closeSimilarTabs(blogmasterobj[usertovisit[0]]);
		});
		setTimeout(reportLogout,4000);
	}

}



function backgroundLogoutold(msg){

	closeSimilarTabs(blogmasterobj[usertovisit[0]]);

	setTimeout(function(){
		var thisuser = getUserArrayByDomain(thisdomain);
		thisuser.msgtype='reportlogout';
		if(withcookie){
			funccallWithCookie(reportLogout)
		}else{
			reportLogout();
		}

		removecache()
	},15000)
}

function checkuserstate(){
	if (testmode==1)
	{return;}
	var datetime=new Date();
	myConsoleLog(0,"FUNCTION checkUserstate:");
	myConsoleLog(2,"now:"+datetime.toString());
	if(userarray.length==0){
		start()
	}else{
		for(var i=0;i<userarray.length;i++){
			var timeout  = userstatetimeout;
			var user=userarray[i];
			if(user.laststate!='start'){timeout=userstatetimeoutSecond}
			if(logined){
				timeout = userstatetimeoutAfterlogin
			}
			if((datetime.getTime()-user.laststatetime.getTime())>timeout){
				myConsoleLog(4,"user"+user.laststatetime.toString());
				user.laststate='notfinish';

				data.laststatetime=new Date();
				reportLogout()
			}
		}
	}

}
//报告proxy超时
function reportUserTimeout(user){
	myConsoleLog(0,'reportusertimeout:')
	if(mode=='vpn'){
		closechrome()
		return
	}
    if(serverajax==1){
        myConsoleLog(2,"serverajax 1")
        return}

	myConsoleLog(0,'Function reportUserTimeout')
    user.msgtype='reportproxytimeout';

	closehosttabs()
	//removecache()
	//removeAllCookies(domainurlobj[msg.domain].cookiedomain);

	serverajax=1;
	jQuery.ajax( {
		url:'http://'+thissiterobotport+'/reportproxytimeout',// 跳转到 action
		data:user,
		type:'get',
		cache:false,
		dataType:'json',
		success:function(data) {
			serverajax=0;
			if(data.code=='nomoreproxy'||data.code=='multiover'){
				console.log('no more proxy');
				removeUserFromUserArrayByDomain(thisdomain);
				if(!directmode){
					closechrome()
				}else{
					getUserAndProxy(thisdomain);
				}
				return;
			}
			var user=getUserArrayByDomain(thisdomain);
			user.ipport=data.ipport;
			user.proxyaddress=data.proxyaddress;
			user.laststatetime=new Date();
			inituserstate();
			setProxy(function () {
				thissitevisitnext(1)
				if(disableuserstate){
					totalvisit()
				}
			});

		},
		error : function(jqxhr,text) {
			serverajax=0;
			jqxhr.abort()
			// view("异常！");
			setTimeout(function () {
				reportUserTimeout(user)
			},2*1000)

			console.log("异常！");
		},
		complete: function (XHR, TS) { XHR = null }
	});
}

//报告异常
function reportException(msg){
    if(serverajax==1){
        myConsoleLog(2,"serverajax 1")
        return}
	serverajax=1;
	jQuery.ajax( {
		url:'http://'+thissiterobotport+'/reportexception',// 跳转到 action
		data:msg,
		type:'get',
		cache:false,
		dataType:'json',
		timeout:100,
		success:function(data) {
			serverajax=0;
		},
		error : function(jqxhr,text) {
			serverajax=0;
			jqxhr.abort()
			// view("异常！");
			console.log("异常！");
		},
		complete: function (XHR, TS) { XHR = null }
	});
}

function myuserstateInterval(startflag){
	if(!disableuserstate){
		if(testmode==1){
			return;
		}
		myConsoleLog(0,"userstateInterval");
		if(startflag==1){
			userstateid =  setInterval(checkuserstate,checkuserstatetimeout);
		}else if(startflag==0 && (userstateid!=null || typeof(userstateid) != undefined)){
			clearInterval(userstateid);
			userstateid = null;
		}
	}


}



//根据domain获取userandproxy
function getUserAndProxy(domain){
    if(serverajax==1){
        myConsoleLog(2,"serverajax 1")
        return}
	//removeAllCookies(domainurlobj[domain].cookiedomain)
	removecache(function () {
		serverajax=1;
		jQuery.ajax( {
			url:'http://'+localagent+'/getuserandproxy',// 跳转到 action
			data:{domain:domain,msgtype:'getuserandproxy'},
			type:'get',
			cache:false,
			dataType:'json',
			success:function(data) {
				serverajax=0;

				inituserstate();
				myConsoleLog(0,'getUserandproxy');
				myConsoleLog(2,JSON.stringify(data));
				if (!directmode){
					if (data.mode=='vpn'){
						mode='vpn'
						setproxy=0;
					}
				}

				if(data.code=='nomoreuser'){
					myConsoleLog(2,'nomore user')
					closeSimilarTabs(domainobj.firsturl)
					return;
				}else if(data.code=='waitforproxy'){
					myConsoleLog(2,'wait for proxy')
					closeSimilarTabs(domainobj.firsturl)
					setTimeout(function () {
						getUserAndProxy(thisdomain)
					},QUERYPROXYUSERCYCLE)
					return;
				}else if(data.code=='loginfinished'){
					myConsoleLog(2,'login finished')
					closeSimilarTabs(domainobj.firsturl)
					myuserstateInterval(0)
					removecachestart()
					if(!directmode){
						closechrome()
					}else{
						start()
					}

					return;
				}else if(data.code=='multirun'){
					myConsoleLog(2,'multi run')
					closeSimilarTabs(domainobj.firsturl)

					referrer=data['referrer'];
					data.laststatetime=new Date();
					data.laststate='start';
					userarray.unshift(data);
					if(withcookie){
						if(data.cookie!='' && data.cookie!=null){
							importCookies(data.cookie)
						}

					}


					setProxy(function () {
						if (typeof(data['lasturl'])!='undefined'){
							rerunpage(data['lasturl']);
							if(disableuserstate){
								totalvisit()
							}
						}

					});
					return;
				}
				if(withmissionmode){
					generatemissionmode();
				}
				data.laststatetime=new Date();
				data.laststate='start';
				userarray.unshift(data);
				if(withcookie){
					if(data.cookie!='' && data.cookie!=null){
						importCookies(data.cookie)
					}

				}
				processuser(data);

				setProxy(function () {
					visitnext(1)
					if(disableuserstate){
						totalvisit()
					}
				});

			},
			error : function(jqxhr,text) {
				serverajax=0;
				jqxhr.abort()
				// view("异常！");
				setTimeout(function () {
					getUserAndProxy(thisdomain)
				},QUERYUSERCYCLE)

				console.log("异常！");
			},
			complete: function (XHR, TS) { XHR = null }
		});
	})


}

function openfirst() {
	myConsoleLog(0,'openfirst')
	if(bremovingcache){
		setTimeout(openfirst,3000)
	}else{
		chrome.tabs.create({'url':domainobj.firsturl});
	}
}

function reportLogout(){
	myConsoleLog(0,"reportLogout")
	if(serverajax==1){
		myConsoleLog(2,"serverajax 1")
		return}
	var thisuser = getUserArrayByDomain(thisdomain);
	if(thisuser==null){
		getUserAndProxy(thisdomain)
		return
	}
	thisuser.msgtype = 'reportlogout';
	serverajax=1;
	jQuery.ajax( {
		url:'http://'+thissiterobotport+'/reportlogout',// 跳转到 action
		data:thisuser,
		type:'get',
		cache:false,
		dataType:'json',
		success:function(data) {
			serverajax=0;
			removeUserFromUserArrayByDomain(thisdomain);
			if(!directmode){
				closechrome()
			}else{
				getUserAndProxy(thisdomain);
			}

		},
		error : function(jqxhr,text) {
			serverajax=0;
			jqxhr.abort()
			setTimeout(function () {
				removeUserFromUserArrayByDomain(thisdomain);
				if(!directmode){
					closechrome()
				}else{
					getUserAndProxy(thisdomain);
				}
			},2*1000)
			// view("异常！");
			console.log("reportlogout异常！");
		},
		complete: function (XHR, TS) { XHR = null }
	});
}

var filter = {
	urls: ["<all_urls>"]
};
//types: [ "main_frame", "sub_frame", "stylesheet", "script", "image", "object", "xmlhttprequest", "other"]



/*
 chrome.webRequest.onAuthRequired.addListener(
 function(details, callback) {
 console.log('onAuthRequired')
 if (details.isProxy) {
 console.log('author proxy')
 callback({authCredentials: {username: 'yaogetit', password: '1qaz5tgb'}});
 } else {
 callback();
 }
 },
 {urls: ["<all_urls>"]},
 ["responseHeaders","blocking"]
 );*/
chrome.webRequest.onAuthRequired.addListener(
	function(details) {
		if(details.isProxy === true){
			return {authCredentials: {username: 'yaogetit', password: '1qaz5tgb'}}
		}

	},
	{urls: ["<all_urls>"]},
	["responseHeaders","blocking"]
);
// chrome.webRequest.onSendHeaders.addListener(function callback(details){
// 	myConsoleLog(0,'onsendheaders: id'+details.requestId)
//
// 	for (var i = 0; i < details.requestHeaders.length; ++i) {
// 		if (details.requestHeaders[i].name === 'User-Agent') {
//
// 			myConsoleLog(2, 'beforeagents:' + details.requestHeaders[i].value)
//
//
//
// 		}
// 		else if (details.requestHeaders[i].name === 'Proxy-Authorization') {
// 			myConsoleLog(2, 'proxy-authorization:' + details.requestHeaders[i].value)
// 		}
// 		else if (details.requestHeaders[i].name == 'Referer' && setreferer && referrer != '') {
// 			myConsoleLog(2, 'referrer:' + details.requestHeaders[i].value)
// 		}
// 	}
// },filter,
// 	["requestHeaders"] )

chrome.webRequest.onBeforeSendHeaders.addListener(

	function(details) {
		var isRefererSet=false;
//		var isauthset=false;
		var usernameandpass='yaogetit:1qaz5tgb'
		var usernamapassbase = Base64.encode(usernameandpass)
		//myConsoleLog(0,'onbeforesendheaders:id'+details.requestId)
		for (var i = 0; i < details.requestHeaders.length; ++i) {
			if(directmode){
				if (details.requestHeaders[i].name === 'User-Agent') {

					//myConsoleLog(2,'beforeagents:'+details.requestHeaders[i].value)
					details.requestHeaders[i].value=agentstr;
					//myConsoleLog(2,'afteragents:'+details.requestHeaders[i].value)


				}
			}

			// else if (details.requestHeaders[i].name === 'Proxy-Authorization') {
			// 	details.requestHeaders[i].value='Basic '+usernamapassbase;
			// 	isauthset=true
			// }
			if (details.requestHeaders[i].name == 'Referer' && setreferer && referrer!='') {
				details.requestHeaders[i].value = referrer;
				isRefererSet = true;
			}
		}

		// if(!isauthset){
		// 	var authdict ={name:'Proxy-Authorization',value:'Basic '+usernamapassbase}
		// 	details.requestHeaders.push(authdict)
		// }

		if (!isRefererSet && setreferer && referrer!='') {
			details.requestHeaders.push({
				name: "Referer",
				value: referrer
			});}
		setreferer=false;
		return {requestHeaders: details.requestHeaders};
	},
	filter,
	["blocking", "requestHeaders"]);
// Create Base64 Object
var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=Base64._utf8_encode(e);while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}else if(isNaN(i)){a=64}t=t+this._keyStr.charAt(s)+this._keyStr.charAt(o)+this._keyStr.charAt(u)+this._keyStr.charAt(a)}return t},decode:function(e){var t="";var n,r,i;var s,o,u,a;var f=0;e=e.replace(/[^A-Za-z0-9+/=]/g,"");while(f<e.length){s=this._keyStr.indexOf(e.charAt(f++));o=this._keyStr.indexOf(e.charAt(f++));u=this._keyStr.indexOf(e.charAt(f++));a=this._keyStr.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+String.fromCharCode(n);if(u!=64){t=t+String.fromCharCode(r)}if(a!=64){t=t+String.fromCharCode(i)}}t=Base64._utf8_decode(t);return t},_utf8_encode:function(e){e=e.replace(/rn/g,"n");var t="";for(var n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t},_utf8_decode:function(e){var t="";var n=0;var r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}}
function start(){
    if(serverajax==1){
        myConsoleLog(2,"serverajax 1")
        return}
	removecachestart(function () {

		serverajax=1;
		console.log('start')
		jQuery.ajax( {
			url:'http://'+thissiterobotport+'/querystart',// 跳转到 action
			data:{'msgtype':'getstart'},
			type:'get',
			cache:false,
			dataType:'json',
			success:function(data) {
				serverajax=0;
				var starttime = data.starttime.split(':')
				var datenow=new Date()
				var startdatetime=new Date(data.starttime)
				var miniseconds = startdatetime-datenow
				myConsoleLog(2,'miniseconds:'+miniseconds)
				if(miniseconds>0){
					setTimeout(function () {
						getMasters()
					},miniseconds)
				}else {
					getMasters()
				}
			},
			error : function(jqxhr,text) {
				serverajax=0;
				jqxhr.abort()
				setTimeout(function () {
					start()
				},10*1000)
				// view("异常！");
				console.log("start 异常！");
			},
			complete: function (XHR, TS) { XHR = null }
		});
	})
}
var bremovingcache=false;

function removecachestart(cb) {
	myConsoleLog(0,'removecachestart:')
	var cb=cb?cb:null;
	if (bremovingcache){
		return
	}
	bremovingcache=true;
	chrome.browsingData.remove({
		"since": 0
	}, {
		"appcache": true,
		"cache": true,
		"cookies": true,
		"downloads": true,
		"fileSystems": true,
		"formData": true,
		"history": true,
		"indexedDB": true,
		"localStorage": true,
		"pluginData": true,
		"passwords": true,
		"webSQL": true
	}, function () {
		bremovingcache=false;
		console.log('removecache over');
		if(cb!=null){
			cb();
		}
	});
}
var strictmodeoptimize=false;
function removecache(cb) {
	myConsoleLog(0,'removecache:')
	var cb=cb?cb:null;
	if (bremovingcache){
		return
	}
	var milliseconds5Minites = 1000 * 60 * 20
	var minisecondsOnceDay = 1000*60*60*24
	var Minitesago20= (new Date()).getTime() - milliseconds5Minites;
	var oneDayAgo = (new Date()).getTime()-minisecondsOnceDay;
	if(!strictmode){

		var removething={
			"appcache": false,
			"cache": false,
			"cookies": true,
			"downloads": false,
			"fileSystems": true,
			"formData": false,
			"history": false,
			"indexedDB": true,
			"localStorage": true,
			"pluginData": false,
			"passwords": false,
			"webSQL": true
		}
	}else {
		console.log('removecache strictmode')
		if(strictmodeoptimize){
			var removething={
				"appcache": true,
				"cache": false,
				"cookies": true,
				"downloads": true,
				"fileSystems": true,
				"formData": true,
				"history": true,
				"indexedDB": true,
				"localStorage": true,
				"pluginData": true,
				"passwords": true,
				"webSQL": true
			}
		}else {
			var removething={
				"appcache": true,
				"cache": true,
				"cookies": true,
				"downloads": true,
				"fileSystems": true,
				"formData": true,
				"history": true,
				"indexedDB": true,
				"localStorage": true,
				"pluginData": true,
				"passwords": true,
				"webSQL": true
			}
		}

	}
	bremovingcache=true;
	chrome.browsingData.remove({
		"since": Minitesago20
	},removething , function () {
		bremovingcache=false;
		console.log('removecache over')
		if(cb!=null){
			cb();
		}
	});
}

function openrandom(msg){
	myConsoleLog(0,'openrandom')
	chrome.tabs.create({url:msg.url}, function (tab){
		chrome.tabs.executeScript(tab.id,{
			code: 'var disablecontentscripts=true;',
			runAt:'document_start'
		});
	})
}
function logfrontpagemsg(msg) {
	var thismsg = '**********frontpage msg:'+msg;
	console.log(thismsg)
}

/**
 * Created by lenovo on 2016/8/27.
 */
function randomsort(a, b) {
	return Math.random()>.5 ? -1 : 1;//用Math.random()函数生成0~1之间的随机数与0.5比较，返回-1或1
}
function getRandomArray(opt) {//数组随机 随机数组
	var old_arry = opt.arry,
		range = opt.range;
	//防止超过数组的长度
	range = range > old_arry.length?old_arry.length:range;
	var newArray = [].concat(old_arry), //拷贝原数组进行操作就不会破坏原数组
		valArray = [];
	for (var n = 0; n < range; n++) {
		var r = Math.floor(Math.random() * (newArray.length));
		valArray.push(newArray[r]);
		//在原数组删掉，然后在下轮循环中就可以避免重复获取
		newArray.splice(r, 1);
	}
	return valArray;
}
// getRandomArray({'arry':[1,6,8,0,3],'range':3});
var swapItems = function(arr, index1, index2) {
	arr[index1] = arr.splice(index2, 1, arr[index1])[0];
	return arr;
};
function processuser(user){
	if (directmode){
		if(parseInt(user.agentindex)>agentsarray.length-1){
			agentstr=agentsarray[0]
		}
		agentstr = agentsarray[user.agentindex]
	}

	usertovisit=new Array()
	usertopraise = new Array()
	usertofan = new Array()
	usertoforward = new Array()
	usertovisitindex = -1;
	var usertovisitp = user.visit.split(';')
	for(i=0;i<usertovisitp.length;i++){
		if(usertovisitp[i]!=''){
			usertovisit.push(usertovisitp[i])
		}
	}
	var usertofanp = user.tofan.split(';')
	for(i=0;i<usertofanp.length;i++){
		if(usertofanp[i]!=''){
			usertofan.push(usertovisitp[i])
		}
	}

	var usertopraisep = user.praise.split(';')
	for(i=0;i<usertopraisep.length;i++){
		if(usertopraisep[i]!=''){
			usertopraise.push(usertovisitp[i])
		}
	}
	var usertoforwardp = user.forward.split(';')
	for(i=0;i<usertoforwardp.length;i++){
		if(usertoforwardp[i]!=''){
			usertoforward.push(usertovisitp[i])
		}
	}
	usertovisit=getRandomArray({'arry':usertovisit,'range':usertovisit.length})
	if(mastertofirstarray.length>0){
		for(i=0;i<usertovisit.length;i++){
			var index = mastertofirstarray.indexOf(usertovisit[i]);
			if(index>=0){
				swapItems(usertovisit,0,i);
				break
			}
		}
	}
	userarray[0].masterfirstlogined=usertovisit[0]
	//create missionobj

	var usercomment = user.comment;

	missionobj={}

	for (var i=0;i<usertovisit.length;i++){
		var masterid = usertovisit[i]
		missionobj[masterid] = {praise:'',comment:'',tofan:'',forward:'',multirun:0}
		missionobj[masterid].debugging = testmode;
		missionobj[masterid].mastername = masternameidobj[masterid];
		if(jQuery.inArray(masterid,usertopraise)>=0){
			missionobj[masterid].praise=masterid;
		}
		if(jQuery.inArray(masterid,usertofan)>=0){
			missionobj[masterid].tofan=masterid;
		}
		if(jQuery.inArray(masterid,usertoforward)>=0){
			missionobj[masterid].forward=masterid;
		}
		if(usercomment!=''){
			var comments = usercomment.split(seperatoruseruser)

			for (var j=0;j<comments.length;j++){
				if(comments[j]!=''){
					cmts = comments[j].split(seperatorusercomment)
					if(cmts[1]!='{}'&&cmts[1]!=''&&cmts[0]==masterid){
						var commentjson=JSON.parse(cmts[1])
						missionobj[masterid].comment=commentjson.comment
						missionobj[masterid].commentlife=commentjson.commentlife
						missionobj[masterid].commentnews=commentjson.commentnews
						missionobj[masterid].commentarticle=commentjson.commentarticle
						break
					}
				}
			}

		}
	}

	multirunind=Math.floor(Math.random()*usertovisit.length);
	missionobj[usertovisit[multirunind]].multirun=1;
}

var withmissionmode=false;

function visitnext(msg) {
	myConsoleLog(0,'visitnext:')
	if(withmissionmode){
		thissitevisitnext()
	}
	else{
		visitnextold()
	}
}

function getnextmission(){
	myConsoleLog(0,'getnextmission:')
	usertovisitindex++;

	if(usertovisitindex<usertovisit.length){
		return missionobj[usertovisit[usertovisitindex]];
	}
	else{
		backgroundLogout()
	}
}

function visitnextold(){
	myConsoleLog(0,'visitnextold:')
	usertovisitindex++;

	if(usertovisitindex<usertovisit.length){
		setTimeout(function () {
			var url = blogmasterobj[usertovisit[usertovisitindex]]
			chrome.tabs.create({url:url},function (tab){
				chrome.tabs.executeScript(tab.id,{
					code: 'var masterid='+usertovisit[usertovisitindex],
					runAt:'document_start'
				});
			});
		},5000)

	}
	else{
		backgroundLogout()
	}
}
missionobj={}


function getMasterMission(msg) {
	myConsoleLog(0,'getmastermission');
	if(typeof (msg.masterid)!='undefined'){
		return missionobj[msg.masterid];
	}else if(typeof(msg.mastername)!='undefined'){
		return missionobj[masternameidobj[msg.mastername]];
	}else{
		return null;
	}
}
function getLastMission(msg) {

	return lastmission;
}

function renewmission(msg) {

	lastmission=msg;
}
/**
 * Closes the tabs that have the same host as the current tab in the current window
 */
function closeSimilarTabs(url) {
	myConsoleLog(0,'closesimilartabs');
	myConsoleLog(2,'tab url:'+url);
	var tabhost,host;

	host = getHost(url);
	myConsoleLog(2,'host:'+host);
	// gets the tabs with the same host
	getTabs(host, function (tabs) {

		// closing the tabs
		tabs.forEach( function (tab, index, array) {
			chrome.tabs.remove(tab.id);
		});
	});


}
/**
 * Returns the tabs that have the same host in the current window
 *
 * @param {String} host
 * @param {Function} successHandler
 */
function getTabs(host, successHandler) {

	chrome.windows.getCurrent( function (win) {
		chrome.tabs.getAllInWindow(win.id, function (tabs) {

			var result = tabs.filter( function (tab, index, array) {

				var tabhost = getHost(tab.url);
				return tabhost == host;
			});

			successHandler(result);
		});
	});

}

/**
 * Returns the hostname
 *
 * from http://beardscratchers.com/journal/using-javascript-to-get-the-hostname-of-a-url
 *
 * @param {String} url
 * @return {String}
 */
function getHost(url) {

	var re = new RegExp('^(?:f|ht)tp(?:s)?\://([^/]+)', 'im'), m;

	if (url != null) {
		m = url.match(re);
		if (m != null) {
			return m[1];
		}
	}

	return url;
}

function openalldomain(){
	getUserAndProxy(thisdomain);

}


var proxyerrorfirsttimeout=15*1000;//20 s timeout
chrome.proxy.onProxyError.addListener(function callback(details){
	myConsoleLog(0,"proxyError");
	console.log(JSON.stringify(details));
	chrome.proxy.settings.get(
		{'incognito': false},
		function(config) {console.log(JSON.stringify(config));});
	if(logined){
		console.log('proxyerror,logined pass')
		return
	}else {
		var datetime=new Date();
		if(userarray.length>0){

			if(datetime.getTime()-userarray[0].laststatetime.getTime()>proxyerrorfirsttimeout){
				myConsoleLog(2,'proxyerrorfirsttimeout')

				reportUserTimeout(userarray[0]);
				if(disableuserstate&&totalvisittimer!=null){
					clearTimeout(totalvisittimer)

				}

			}
		}
		else {
            getUserAndProxy(thisdomain)
        }

	}

})
function openurl(url){
	myConsoleLog(0,'openurl')
	chrome.tabs.create({url:url},function callback(){});
}


function updateUserstate(user){
	user.laststatetime=new Date();
}
function getProxySetting(){
	chrome.proxy.settings.get(
		{'incognito': false},
		function(config) {console.log(JSON.stringify(config));});
}

function setProxy(callback){
	myConsoleLog(0,'setProxy:')
	logined=false
	myConsoleLog(0,'setProxy');
	if(!strictmode){
		var pactmp="";
		for(var i=0;i<userarray.length;i++){
			pactmp+=domainobj.pac.replace('MYOWENIPPORT',userarray[i].ipport);
		}
		var pac=pacstart+pactmp+pacend;
	}else{
		var pac = "var FindProxyForURL = function(url, host){if(isPlainHostName(host)||isInNet(host,'192.168.1.1','255.255.0.0')||isInNet(host,'127.0.0.1','255.255.255.255'))" +
			"{return 'DIRECT';}else{return 'PROXY MYOWENIPPORT';}}".replace('MYOWENIPPORT',userarray[0].ipport)
	}

	myConsoleLog(2,pac);
	var config = {
		mode: "pac_script",
		pacScript: {
			data: pac,
			mandatory:true
		}
	};
	if(setproxy==1){
		myConsoleLog(2,'proxyseted')
		chrome.proxy.settings.clear({});
		chrome.proxy.settings.set(		{value: config, scope: 'regular'},		function() {callback()});
	}else {
		callback()
	}

}

function myConsoleLog(empties,info){
	var empty=" ";
	var temp=" ";
	for(var i=0;i<empties;i++){
		temp+=empty;
	}
	console.log(temp+info);
}

function getUserArrayByDomain(domain){
	for(var i=0;i<userarray.length;i++){
		if(userarray[i].domain==domain){
			return userarray[i];
		}

	}
	return null;
}
//从userarray中移除
function removeUserFromUserArrayByDomain(domain){
	for(var i=0;i<userarray.length;i++){
		if(userarray[i].domain==domain) {
			userarray.splice(i,1);
			return true;
		}
	}
}


var cookieList = new Array();


var withcookie=false;
function funccallWithCookie(callback) {
	var filteredCookies = [];
	var filter = new Filter();
	var filters = filter.getFilter();
	chrome.cookies.getAll(filters, function(cks) {
		var currentC;
		for(var i=0; i<cks.length; i++) {
			currentC = cks[i];

			if(filters.name != undefined && currentC.name.toLowerCase().indexOf(filters.name.toLowerCase()) == -1)
				continue;
			if(filters.domain != undefined && currentC.domain.toLowerCase().indexOf(filters.domain.toLowerCase()) == -1)
				continue;
			if(filters.secure != undefined && currentC.secure.toLowerCase().indexOf(filters.secure.toLowerCase()) == -1)
				continue;
			if(filters.session != undefined && currentC.session.toLowerCase().indexOf(filters.session.toLowerCase()) == -1)
				continue;

			for(var x=0; x<data.readOnly.length; x++) {
				try {
					var lock = data.readOnly[x];
					if(lock.name == currentC.name && lock.domain == currentC.domain) {
						currentC.isProtected = true;
						break;
					}
				} catch(e){
					console.error(e.message);
					delete data.readOnly[x];
				}
			}
			filteredCookies.push(currentC);
		}
		cookieList = filteredCookies;
		var jsoncookie =	cookiesToString.get(cookieList)
		var user=getUserArrayByDomain(thisdomain);
		user.cookie=jsoncookie;
		callback()

	});

}

function importCookies(text) {
	var nCookiesImportedThisTime = 0;

	try {
		var cookieArray = $.parseJSON(text);
		if(Object.prototype.toString.apply(cookieArray) === "[object Object]")
			cookieArray = [cookieArray];
		for(var i=0; i<cookieArray.length; i++) {
			try {
				var cJSON = cookieArray[i];
				var cookie = cookieForCreationFromFullCookie(cJSON);
				chrome.cookies.set(cookie);
				nCookiesImportedThisTime++;
			} catch(e) {
				console.error(e.message);

				return;
			}
		}
	} catch(e) {

		console.error(e.message);

		return;
	}
	data.nCookiesImported += nCookiesImportedThisTime
	return;
}
function notlogin(){
	usertovisitindex--;
}
function backwardusertovisit(){
	usertovisitindex--;
}
function backgroundlogin(){
	usertovisitindex--;
	openfirst()
}
agentsarray=[
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko',
	'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36 Edge/15.15063',
	'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
	'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.1.1 Safari/603.2.4',
	'Mozilla/5.0 (X11; Linux x86_64; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0',
	'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:54.0) Gecko/20100101 Firefox/54.0',
	'Mozilla/5.0 (iPad; CPU OS 10_3_3 like Mac OS X) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.0 Mobile/14G60 Safari/602.1',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393',
	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:54.0) Gecko/20100101 Firefox/54.0',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/60.0.3112.78 Chrome/60.0.3112.78 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko',
	'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36 OPR/47.0.2631.55',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/60.0.3112.113 Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36 OPR/47.0.2631.71',
	'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0; Trident/5.0)',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
	'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.5.17 (KHTML, like Gecko) Version/8.0.5 Safari/600.5.17',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36',
	'Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0; Trident/5.0)',
	'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; rv:54.0) Gecko/20100101 Firefox/54.0',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8',
	'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0',
	'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.1 Safari/603.1.30',
	'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0',
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.101 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36',
	'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko'];
var agentstr = agentsarray[0]

var missionmode='background';
function generatemissionmode(){
	myConsoleLog(0,'generatemissionmode');

	var randnum=Math.random();
	console.log('randnum:'+randnum)
	var tmpnum=0;
	for(key in missionmodedict){

		tmpnum+=missionmodedict[key];
		console.log('key and tmpnum:'+key+tmpnum)
		if(randnum<tmpnum){
			missionmode=key;
			break;
		}
	}
	myConsoleLog(2,"missionmode:"+missionmode)
}
listtabid=null;
setreferer=false;
function rerunpage(url){
	setreferer=true;
	chrome.tabs.create({url:url},function (tab) {
		chrome.tabs.executeScript(tab.id,{
			code: 'var multirunpage=true',
			runAt:'document_start'
		})
	})
}



function closehosttabs(){
	for(i=0;i<hostarray.length;i++){
		closeSimilarTabs(hostarray[i]);
	}
}

chrome.contentSettings["popups"].set({
	'primaryPattern': "<all_urls>",
	'setting': "allow",
	'scope': ('regular')
});
chrome.contentSettings["plugins"].set({
	'primaryPattern': "<all_urls>",
	'setting': "allow",
	'scope': ('regular')
});
jQuery('document').ajaxComplete(function( event, xhr, settings ) {
	myConsoleLog(0,'ajaxComplete:')
	xhr=null;
	serverajax=0;
});
jQuery('document').ajaxStop(function(){
	myConsoleLog(0,'ajaxstop:')
	serverajax=0;
})
function setTotaltime(){

}


function closechrome(){
	myConsoleLog(0,'closechrome')
	if(!testmode){
		chrome.windows.getAll({}, function (wind){
			for(i=0;i<wind.length;i++){
				chrome.windows.remove(wind[i].id)
			}

		})
	}

}
//"normal"
//"minimized"
//"maximized"
//"fullscreen"
function changewindowstate(state){
	chrome.windows.getAll({}, function (wind){
		for(i=0;i<wind.length;i++){
			chrome.windows.update(wind[i].id,{state:state})
		}

	})
}


function cantcontinue(){
	myConsoleLog(0,"can't continue");
	closechrome()
}

function getscreenbackground(sendResponse) {
myConsoleLog(0,'getscreenbackground');
        jQuery.ajax({
            url: 'http://' + thissitemouseport + '/screenlock',// 跳转到 action
            data: {'msgtype': 'getscreen'},
            type: 'get',
            cache: false,
            dataType: 'json',
            timeout: mousetimeout,
            success: function (data) {
                if (data.code == 'success') {

                    changewindowstate('maximized')
					setTimeout(function () {
						sendResponse({code:'success'})
                    },6000)


                } else if (data.uimsgtype == "fail") {
					myConsoleLog(2,'getscreen fail')
                    getscreenbackground(sendResponse);
                }
            },
            error: function (jqxhr, text) {

                jqxhr.abort()

                myConsoleLog(2,'getscreen ')
                getscreenbackground(sendResponse);
            },
            complete: function (XHR, TS) {
                XHR = null;
            }
        });

}
jumped=false
function jumppage(url) {
	if(!jumped){
		jumped=true;
		chrome.tabs.create({url:url},function (tab) {
			chrome.tabs.executeScript(tab.id,{
				code: 'window.open("'+homeurl+'")',
				runAt:'document_end'
			})
		})
	}

}
totalvisittimer=null
totalvisittime=2*60*1000
function totalvisit(){
	myConsoleLog(0,'totalvisit')
	disableuserstate=true
	myuserstateInterval(0)
	totalvisittime = Math.floor(Math.random()*(totalvisitmax-totalvisitmin)+totalvisitmin)
	if (totalvisittimer!=null || typeof(totalvisittimer) != undefined){
	clearTimeout(totalvisittimer)
		totalvisittimer=null
}
	totalvisittimer = setTimeout(function () {
		myConsoleLog(2,'totalvisittimer')
		if(!logined){
			var user=getUserArrayByDomain(thisdomain);
			if(user!=null){
				user.laststate='notfinish';
				user.laststatetime=new Date();
                reportUserTimeout(user)
			}

		}
		backgroundLogout()
	},totalvisittime)
}
function closeothertabs(){
	myConsoleLog(0,'closeothertabs')
	chrome.tabs.query({}, function(tabs){
		for(var i=0;i<tabs.length;i++){
			myConsoleLog(0,tabs[i].url)
			if(tabs[i].url!='chrome://extensions/' && tabs[i].url!='chrome://newtab/'&&tabs[i].url!='chrome://settings/'&&
				tabs[i].url!='chrome://welcome/'&&tabs[i].url!='about:blank'&&tabs[i].url!=''){
				chrome.tabs.remove(tabs[i].id)
			}
		}
	})
}
function closeothertabst(){
	chrome.tabs.query({}, function(tabs){
		for(var i=0;i<tabs.length;i++){

			if(tabs[i].url!='chrome://extensions/' && tabs[i].url!='chrome://newtab/'&&tabs[i].url!='chrome://settings/'&&
				tabs[i].url!='chrome://welcome/'&&tabs[i].url!='about:blank'&&tabs[i].url!=''){
				myConsoleLog(2,'hit one:'+tabs[i].url)
			}else{
				myConsoleLog(0,tabs[i].url)
			}
		}
	})
}
closehosttabs=closeothertabs