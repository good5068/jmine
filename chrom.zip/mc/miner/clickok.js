
function checkva(){
    var pv=document.getElementsByClassName("allow");
    if(pv.length==1){
        pv[0].click();
    }else{
        setTimeout(checkva,3000)
    }
}
checkva();