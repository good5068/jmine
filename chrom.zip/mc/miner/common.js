function logout(){
        var msg={"msgtype":"reportlogout",
            "url":window.location.origin,
            "tabdomain":window.location.hostname,
            "domain":thissiteconfig.domain
        };
         chrome.runtime.sendMessage(msg);
    
}
function passerror(){
    var msg={"msgtype":"reportpasserror",
        "url":window.location.origin,
        "tabdomain":window.location.hostname,
        "domain":thissiteconfig.domain
    };
    chrome.runtime.sendMessage(msg);

}

function delaybackgroundtimer() {
    chrome.runtime.sendMessage({'msgtype':'changestate','domain':thissiteconfig.domain,'state':'delay'});
}

function nextpage(){
    if(localStorage.debugging=='0'){
        setTimeout(function () {
            chrome.runtime.sendMessage({'msgtype':'donextvisit','domain':thissiteconfig.domain});
        },20000)
    }
}

/**
 * Created by catmao on 2016/8/27.
 */
function randomsort(a, b) {
    return Math.random()>.5 ? -1 : 1;//用Math.random()函数生成0~1之间的随机数与0.5比较，返回-1或1
}
function getRandomArray(opt) {//数组随机 随机数组
    var old_arry = opt.arry,
        range = opt.range;
    //防止超过数组的长度
    range = range > old_arry.length?old_arry.length:range;
    var newArray = [].concat(old_arry), //拷贝原数组进行操作就不会破坏原数组
        valArray = [];
    for (var n = 0; n < range; n++) {
        var r = Math.floor(Math.random() * (newArray.length));
        valArray.push(newArray[r]);
        //在原数组删掉，然后在下轮循环中就可以避免重复获取
        newArray.splice(r, 1);
    }
    return valArray;
}
// getRandomArray({'arry':[1,6,8,0,3],'range':3});
randomfunc= new Array()
serialfunc= new Array()
function pagemission(randfun,serialfun){
    randomfunc=randfun;
    serialfunc=serialfun;
    randomfunc=getRandomArray({'arry':randomfunc,'range':randomfunc.length})
    nextfunc()
}
function nextfunc(timeout) {//访问下一个函数 default 0
    var timeout = arguments[0] ? arguments[0] : 0
    if(randomfunc.length>0){
        var nextfunctocall=randomfunc.pop()
        setTimeout(nextfunctocall,timeout)
    }else if(serialfunc.length>0){
        var nextfunctocall=serialfunc.pop()
        setTimeout(nextfunctocall,timeout)
    }

}

function pagehrefrandom0(rate=0.7) {

    var num=Math.random()
    if(num>rate){return}

    window.open(getpagehref())


}
function pagehrefrandom5(rate=0.7) {

    var num=Math.random()
    if(num>rate){return}
    setTimeout(function () {
        console.log('do rand page')
        window.open(getpagehref())
    },t5s);

}
function pagehrefrandom10(rate=0.7) {

    var num=Math.random()
    if(num>rate){return}
    setTimeout(function () {
        console.log('do rand page')
        window.open(getpagehref())
    },t10s);

}

function pagehrefrandom15(rate=0.7) {

    var num=Math.random()
    if(num>rate){return}
    setTimeout(function () {
        console.log('do rand page')
        window.open(getpagehref())
    },t15s);

}
function pagehrefrandom20(rate=0.7) {

    var num=Math.random()
    if(num>rate){return}
    setTimeout(function () {
        console.log('do rand page')
        window.open(getpagehref())
    },t20s);

}

function pagehrefrandom25(rate=0.7) {

    var num = Math.random()
    if (rate > num) {
        return
    }
    setTimeout(function () {
        console.log('do rand page')
        window.open(getpagehref())
    }, t25s);
}
function pagehrefrandom30(rate=0.7) {

    var num=Math.random()
    if(num>rate){return}
    setTimeout(function () {
        console.log('do rand page')
        window.open(getpagehref())
    },t30s);

}
function pagehrefrandom35(rate=0.7) {

    var num=Math.random()
    if(num>rate){return}
    setTimeout(function () {
        console.log('do rand page')
        window.open(getpagehref())
    },t35s);
}

function pagehrefrandom40(rate=0.7) {

    var num=Math.random()
    if(num>rate){return}
    setTimeout(function () {
        console.log('do rand page')
        window.open(getpagehref())
    },t40s);
}
function singlehrefrandom10(url,rate=0.7) {

    var num=Math.random()
    if(num>rate){return}
    setTimeout(function () {
        console.log('do rand page')
        window.open(url)
    },t10s);
}
function getpagehref(){
    var href=''
    var alist=jQuery('a')
    while(href==''||href[0]=='j'){
        var aindex=Math.floor(Math.random()*alist.length);
        href=alist[aindex].href;
    }
    return href
}




function ajaxcheck(checkfunc,successfunc,failfunc,timeout,times) {
    successfunc=successfunc?successfunc:function () {
        console.log('default successfunc')
    };
    failfunc=failfunc?failfunc:function () {
        console.log('default failfunc')
    }
    setTimeout(function () {
        if(times>0){
            if(checkfunc()){
                successfunc()
            }else{
                failfunc()
            }
            times--;
        }
    },timeout)

}


function getcomment(blogdetail,msg){
    var commentinfo=msg.comment
    if(blogdetail[0]=='['||blogdetail[0]=='【'){
        commentinfo=msg.commentnews
    }else if(blogdetail[0]=='"'||blogdetail[0]=='“'){
        commentinfo=msg.comment
    }else if(blogdetail[0]=='《'){
        commentinfo=msg.commentarticle
    }else if(blogdetail[0]=='*'){
        commentinfo=msg.commentlife
    }
    return commentinfo
}

function cantcontinue() {
    chrome.runtime.sendMessage({'msgtype':'cantcontinue'});
}

function maximizedanddo(cb,delay) {
    chrome.runtime.sendMessage({'msgtype':'changewindowstate','state':'maximized'},function(response){
        setTimeout(cb,delay);
    })
}


function normalanddo(cb,delay) {
    chrome.runtime.sendMessage({'msgtype':'changewindowstate','state':'normal'},function(response){
        setTimeout(cb,delay);
    })
}

function jumppage(){
    var msg={"msgtype":"queryjumppage"
    };
    chrome.runtime.sendMessage(msg,function (response){
        if(response.jumped==false){
            window.open(thissiteconfig.hosturl)
        }

    });
}

function reportlogined() {
    chrome.runtime.sendMessage({'msgtype':'changestate','domain':thissiteconfig.domain,'state':'login'});
}

function closeme(timeout) {
    setTimeout(function () {
        chrome.runtime.sendMessage({'msgtype':'closeme'});
    },timeout)
}

function keepvisiting() {
    setTimeout(function () {
        setTimeout(pagehrefrandom0,totalvisittime*2/3)
    },2000)

}